# @app.route('/',methods=["GET","POST"])
# def hello_world():
#     if request.method=="POST":
#         idnamee =request.form['form2Example1']
#         password=request.form['form2Example2']
#         display(idnamee,password)
#         return redirect('/display')
#     return render_template("index.html")

# @app.route('/display')
# def display(idnamee,password):
#     return render_template("index1.html",idnamee = idnamee, password =password)


# @app.route("/")
# def index():
#     return  render_template("index.html")

#  <form action="{{ url_for("gfg")}}" method="post">
#                     <div class="form-outline mb-4">
#                         <input type="email" id="id_name" name = "fname"class="form-control form-control-lg">
#                         <label class="form-label" for="id_name">Email</label>
#                     </div>
                    
#                     <div class="form-outline mb-4">
#                         <input type="password" id="password" name ="lname" class="form-control form-control-lg">
#                         <label class="form-label" for="password">Password</label>

#                     </div>

#                     <hr class="my-4">
      
#                         <button class="btn btn-lg btn-block btn-primary" style="background-color: #dd4b39;"
#                             type="submit"><i class="fab fa-google me-2"></i> Sign in with google</button>
#                         <button class="btn btn-lg btn-block btn-primary mb-2" style="background-color: #3b5998;"
#                             type="submit"><i class="fab fa-facebook-f me-2"></i>Sign in with facebook</button>

#                  </form> 