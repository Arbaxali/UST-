import json
import pymongo
import pandas as pd 

def mongoimport(csv_path,column_name):
    client = pymongo.MongoClient("mongodb://localhost:27017")
    print(client)
    db=client['pymongoDB']
    collection=db['transactions']

    collection.delete_many({})
    transaction_df = pd.read_csv(csv_path, names = column_name)
    payload = json.loads(transaction_df.to_json(orient = 'records'))
    collection.insert_many(payload)


column_name = ['_id', 'date', 'transaction_id', 'amount', 'category', 'productname',
               'city', 'country', 'payment_details']
mongoimport("C:/Users/anu/Documents/python programs/Data/transactions.csv",column_name)



