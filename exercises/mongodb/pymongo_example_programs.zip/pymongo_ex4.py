import pymongo



if __name__ == "__main__":
    print('welcome to PyMongo')
    client = pymongo.MongoClient("mongodb://localhost:27017")
    print(client)
    db=client['pymongoDB']
    collection=db['transactions']

    # Run queries using pymongo on document
    all_doc=collection.aggregate([{ '$group' :
                                        {'_id' : '$category', 'averageAmount':
                                        {'$avg' : '$amount'}}}])
    # for item in all_doc:
    #     print(item)


    # Display counts of each category in transactions
    count_category=collection.aggregate([{ '$group' :
                                        {'_id' : '$category', 'countCategory':
                                        {'$count' : {}}}}])
    # for item in count_category:
    #     print(item)


    # Display count odf each category in transaction in descending order
    count_category=collection.aggregate([{ '$group' :
                                        {'_id' : '$category', 'countCategory':
                                        {'$count' : {}}}},{'$sort':{'countCategory':-1}}])

    # for item in count_category:
    #     print(item)

    count_Product=collection.aggregate ([{ '$group' :
                                        {'_id' : '$productname', 'countProduct':
                                        {'$count' : {}}}},{'$sort':{'countProduct':-1}},{'$limit':5}])

    # for item in count_Product:
    #     print(item)


    count_Product=collection.aggregate ([{ '$group' :
                                        {'_id' : '$productname', 'countProduct':
                                        {'$count' : {}}}},{'$sort':{'countProduct':1}},{'$limit':5}])

    for item in count_Product:
        print(item)